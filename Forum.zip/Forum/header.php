<center><a href ="index.php">Forum Homepage</a> | <a href="account.php">My Account</a> |<a href="members.php"> Members</a> | <a href="index.php?action=logout">Logout</a></center>
